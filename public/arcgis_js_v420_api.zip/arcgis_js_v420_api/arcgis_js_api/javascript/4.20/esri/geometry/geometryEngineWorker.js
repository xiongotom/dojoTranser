// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["exports","../chunks/geometryEngineJSON"],function(a,c){a.executeGEOperation=function(b){return(0,c.geometryEngineJSON[b.operation])(...b.parameters)};Object.defineProperty(a,"__esModule",{value:!0})});