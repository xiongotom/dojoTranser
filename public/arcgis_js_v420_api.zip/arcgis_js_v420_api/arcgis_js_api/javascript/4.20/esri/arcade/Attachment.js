// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["../chunks/_rollupPluginBabelHelpers","./Dictionary"],function(d,e){return function(b){function c(f,g,h,k,l){var a=b.call(this)||this;a.attachmentUrl=l;a.immutable=!1;a.setField("id",f);a.setField("name",g);a.setField("contenttype",h);a.setField("size",k);a.immutable=!0;return a}d._inheritsLoose(c,b);return c}(e)});