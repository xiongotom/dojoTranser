// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["../chunks/_rollupPluginBabelHelpers","./Dictionary"],function(d,e){return function(b){function c(f){var a=b.call(this)||this;a.immutable=!1;a.setField("url",f);a.immutable=!0;return a}d._inheritsLoose(c,b);return c}(e)});