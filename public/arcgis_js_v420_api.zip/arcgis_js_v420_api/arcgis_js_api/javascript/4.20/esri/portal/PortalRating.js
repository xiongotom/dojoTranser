// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define("../chunks/_rollupPluginBabelHelpers ../chunks/tslib.es6 ../core/Accessor ../core/accessorSupport/decorators/property ../core/has ../core/accessorSupport/ensureType ../core/Logger ../core/jsonMap ../core/accessorSupport/decorators/subclass".split(" "),function(g,c,a,d,k,l,m,n,h){a=function(e){function f(b){b=e.call(this,b)||this;b.created=null;b.rating=null;return b}g._inheritsLoose(f,e);return f}(a);c.__decorate([d.property()],a.prototype,"created",void 0);c.__decorate([d.property()],a.prototype,
"rating",void 0);return a=c.__decorate([h.subclass("esri.portal.PortalRating")],a)});