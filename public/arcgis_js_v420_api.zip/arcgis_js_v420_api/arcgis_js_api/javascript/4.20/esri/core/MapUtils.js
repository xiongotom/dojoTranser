// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){b.findInMap=function(c,d){for(const [e,a]of c)if(d(a,e))return a;return null};b.someMap=function(c,d){for(const [e,a]of c)if(d(a,e))return!0;return!1};Object.defineProperty(b,"__esModule",{value:!0})});