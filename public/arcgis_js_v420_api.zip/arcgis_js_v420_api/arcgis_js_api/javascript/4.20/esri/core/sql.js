// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["require","exports","../chunks/_rollupPluginBabelHelpers"],function(e,b,f){function a(){a=f._asyncToGenerator(function*(c,d){const {WhereClause:g}=yield new Promise(function(h,k){e(["./sql/WhereClause"],h,k)});return g.create(c,d)});return a.apply(this,arguments)}b.parseWhereClause=function(c,d){return a.apply(this,arguments)};Object.defineProperty(b,"__esModule",{value:!0})});