// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["../chunks/_rollupPluginBabelHelpers","./Message"],function(c,a){a=function(d){function b(e,f,g){var h=d.call(this,e,f,g)||this;return c._assertThisInitialized(h)instanceof b?h:new b(e,f,g)}c._inheritsLoose(b,d);return b}(a);a.prototype.type="warning";return a});