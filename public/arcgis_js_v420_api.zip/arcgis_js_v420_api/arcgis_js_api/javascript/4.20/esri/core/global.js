// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(function(){return function(){if("undefined"!==typeof globalThis)return globalThis;if("undefined"!==typeof self)return self;if("undefined"!==typeof window)return window;if("undefined"!==typeof global)return global}()});