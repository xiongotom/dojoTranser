// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){b.find=function(c,d){for(const a of c)if(null!=a&&d(a))return a};Object.defineProperty(b,"__esModule",{value:!0})});