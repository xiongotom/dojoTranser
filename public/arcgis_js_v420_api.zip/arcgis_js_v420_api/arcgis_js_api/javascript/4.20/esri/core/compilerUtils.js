// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["exports","./has"],function(a,c){a.neverReached=function(b){};a.neverReachedSilent=function(b){};a.tuple=(...b)=>b;a.typeCast=function(b){return()=>b};Object.defineProperty(a,"__esModule",{value:!0})});