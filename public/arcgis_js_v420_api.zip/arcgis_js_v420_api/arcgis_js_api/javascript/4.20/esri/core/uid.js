// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["exports"],function(a){let b=0;a.NullUID=0;a.generateUID=function(){return++b};Object.defineProperty(a,"__esModule",{value:!0})});