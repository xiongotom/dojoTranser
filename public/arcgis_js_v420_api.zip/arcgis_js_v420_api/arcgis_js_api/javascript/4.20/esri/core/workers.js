// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["exports","./workers/workers","./workers/Connection","./workers/RemoteClient"],function(a,b,c,d){a.initialize=b.initialize;a.open=b.open;a.openWithPorts=b.openWithPorts;a.terminate=b.terminate;a.Connection=c;a.RemoteClient=d;Object.defineProperty(a,"__esModule",{value:!0})});