// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){b.Milliseconds=function(a){return a};b.MillisecondsFromSeconds=function(a){return 1E3*a};b.Seconds=function(a){return a};b.SecondsFromMilliseconds=function(a){return.001*a};Object.defineProperty(b,"__esModule",{value:!0})});