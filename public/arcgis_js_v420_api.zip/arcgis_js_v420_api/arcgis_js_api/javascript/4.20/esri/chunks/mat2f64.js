// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){function d(){return[1,0,0,1]}function e(a){return[a[0],a[1],a[2],a[3]]}function f(a,c,h,k){return[a,c,h,k]}function g(a,c){return new Float64Array(a,c,4)}var l=Object.freeze({__proto__:null,create:d,clone:e,fromValues:f,createView:g});b.clone=e;b.create=d;b.createView=g;b.fromValues=f;b.mat2f64=l});