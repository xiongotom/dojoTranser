// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See https://js.arcgis.com/4.20/esri/copyright.txt for details.
//>>built
define(["exports"],function(b){function d(){return[1,0,0,1,0,0]}function e(a){return[a[0],a[1],a[2],a[3],a[4],a[5]]}function f(a,c,h,k,l,m){return[a,c,h,k,l,m]}function g(a,c){return new Float64Array(a,c,6)}var n=Object.freeze({__proto__:null,create:d,clone:e,fromValues:f,createView:g});b.clone=e;b.create=d;b.createView=g;b.fromValues=f;b.mat2df64=n});